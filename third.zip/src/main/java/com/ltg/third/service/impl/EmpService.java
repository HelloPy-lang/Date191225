package com.ltg.third.service.impl;

import com.ltg.third.dao.IEmpDao;
import com.ltg.third.dao.impl.EmpDao;
import com.ltg.third.pojo.Emp;
import com.ltg.third.service.ImpService;

/**
 * ����ӿڵ�ʵ����
 * @author shujie
 *
 */
public class EmpService implements ImpService {
	// ��ȡר�Ŵ����־ò㷽��Ķ���
	private IEmpDao empDao=new EmpDao();

	@Override
	public Emp findEmpByNicknameAndPassword(String nickname, String password) {
		return empDao.findEmpByNicknameAndPassword(nickname,password);
	}

	@Override
	public boolean findEmpByNickname(String nickname) {
		return empDao.findEmpByNickname(nickname);
	}

	@Override
	public void registerEmp(Emp emp) {
		empDao.registerEmp(emp);
		
	}

}
