package com.ltg.third.service;

import com.ltg.third.pojo.Emp;

/**
 * ����ӿ�
 * @author shujie
 *
 */
public interface ImpService {
	Emp findEmpByNicknameAndPassword(String nickname,String password);

	boolean findEmpByNickname(String nickname);

	void registerEmp(Emp emp);
}
