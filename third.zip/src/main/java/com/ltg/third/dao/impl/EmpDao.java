package com.ltg.third.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ltg.third.dao.IEmpDao;
import com.ltg.third.pojo.Emp;
import com.ltg.third.utils.MyDBUtils;

/**
 * �־ò��ʵ����
 * @author shujie
 *
 */
public class EmpDao implements IEmpDao {

	@Override
	public Emp findEmpByNicknameAndPassword(String nickname, String password) {
		
		String sql="select * from emp where nickname=? and password=?";
		//��ȡ���ݿ����Ӷ���
		Connection conn=MyDBUtils.getConnection();
		
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			//��ȡԤ�������
			ps.setString(1, nickname);
			ps.setString(2, password); //��ռλ����ֵ
			
			//ִ��sql��䣬��ý����
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				//��ȡ���ݿ��ж�Ӧ��ֵ
				int id=rs.getInt("id");
				String gender=rs.getString("gender");
				double salary=rs.getDouble("salary");
				
				Emp emp=new Emp(id,nickname,password,gender,salary);
				return emp;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				//�Ͽ����ӣ��ͷ���Դ
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
	}

	@Override
	public boolean findEmpByNickname(String nickname) {
		String sql="select * from emp where nickname=?";
		//��ȡ���ݿ����Ӷ���
		Connection conn=MyDBUtils.getConnection();
		try {
			//��ȡԤ�������
			PreparedStatement ps=conn.prepareStatement(sql);
			//��ռλ����ֵ
			ps.setString(1, nickname);
			//ִ��sql���
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public void registerEmp(Emp emp) {
		String sql="insert into emp values(null,?,?,?,?)";
		Connection conn=MyDBUtils.getConnection();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			//��ռλ����ֵ
			ps.setString(1, emp.getNickname());
			ps.setString(2, emp.getPassword());
			ps.setString(3, emp.getGender());
			ps.setDouble(4, emp.getSalary());
			//ִ����ɾ�Ķ���ʹ��executeUpdate����
			ps.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
