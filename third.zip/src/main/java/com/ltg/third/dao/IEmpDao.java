package com.ltg.third.dao;

import com.ltg.third.pojo.Emp;

/**
 * emp�ĳ־ò�ӿ�
 * @author shujie
 *
 */
public interface IEmpDao {
	/**
	 * ͨ���ǳƺ��������emp����
	 * @param nickname
	 * @param password
	 * @return
	 */
	Emp findEmpByNicknameAndPassword(String nickname,String password) ;

	boolean findEmpByNickname(String nickname);

	void registerEmp(Emp emp);
}
