package com.ltg.third.test;

import java.sql.Connection;
import com.ltg.third.utils.*;

public class TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=MyDBUtils.getConnection();
		System.out.println(conn);
	}

}
